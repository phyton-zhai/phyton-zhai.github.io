# backtest_corn.py
# 玉米回测：模型涌现策略 vs 北大荒标准农田方案
import json, math, os

# ==================== 天气加载 ====================
def load_weather_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        raw = json.load(f)
    return raw

def extract_season(raw, year_start, end_month=9, end_day=30):
    def find_index(raw, target):
        for i, t in enumerate(raw['hourly']['time']):
            if t.startswith(target): return i
        return None
    i1 = find_index(raw, f"{year_start}-06-01")
    i2 = find_index(raw, f"{year_start}-{end_month:02d}-{end_day:02d}")
    if i1 is None: raise ValueError(f"无法定位: {year_start}-06-01")
    if i2 is None: i2 = len(raw['hourly']['time']) - 1
    records = []
    for i in range(i1, i2+1):
        records.append({
            'temp': raw['hourly']['temperature_2m'][i] or 25.0,
            'precip': raw['hourly']['precipitation'][i] or 0.0,
            'solar': raw['hourly']['shortwave_radiation'][i] or 300.0,
            'humidity': raw['hourly']['relative_humidity_2m'][i] or 60.0,
            'time': raw['hourly']['time'][i]
        })
    return records

def build_season(weather_dir, city, year_start):
    fname = f"weather_{city}_{year_start}.json"
    fpath = os.path.join(weather_dir, fname)
    if not os.path.exists(fpath):
        fpath = os.path.join(weather_dir, "..", "冬小麦最终成果包", "weather", fname)
    if not os.path.exists(fpath):
        fpath = os.path.join(weather_dir, fname)
    raw = load_weather_file(fpath)
    return extract_season(raw, year_start, 9, 30)

# ==================== 土壤 ====================
class SimpleSoil:
    def __init__(self):
        self.moisture = 0.25; self.fc = 0.25; self.wp = 0.08
    def update(self, p, t, r):
        self.moisture += min(p, 15)/100
        self.moisture -= 0.002*(t/20)*(self.moisture/self.fc)
        self.moisture = max(self.wp, min(self.fc, self.moisture))
    def aw(self):
        if self.moisture <= self.wp: return 0.0
        return (self.moisture - self.wp)/(self.fc - self.wp)

# ==================== 模型涌现策略植格 ====================
class CornAgent:
    def __init__(self, genome):
        self.g = genome
        self.energy = 20.0; self.water = 12.0; self.nitrogen = 8.0
        self.height = 0.1; self.root = 0.1; self.leaf = 0.1
        self.biomass = 0.1; self.gdd = 0.0
        self.age_hours = 0; self.age_days = 0
        self.headed = False; self.mature = False
        self.grain_energy = 0.0
        self.alive = True; self.stage = "播种-出苗"; self.death_cause = None
        self.ops = []; self.last_irrigation_hour = -1000

        self.max_height = self.g['max_height']; self.max_root = self.g['max_root_depth']
        self.leaf_max = 6.0; self.water_stress = 2.0
        self.plant_density = self.g['plant_density']
        self.light_comp = self.g['light_comp']; self.root_comp = self.g['root_comp']
        self.gdd_emergence = self.g['gdd_emergence']
        self.gdd_jointing = self.g['gdd_jointing']
        self.gdd_heading = self.g['gdd_heading']
        self.gdd_maturity = self.g['gdd_maturity']

    def update(self, w, soil):
        if not self.alive or self.mature: return
        temp, precip, solar = w['temp'], w['precip'], w['solar']
        g = self.g

        self.age_hours += 1
        if self.age_hours % 24 == 0: self.age_days += 1
        self.gdd += max(0.0, (temp-10.0)/24.0)
        soil.update(precip, temp, self.root)
        aw = soil.aw()

        lai = self.leaf*self.plant_density/667.0
        light = solar*math.exp(-self.light_comp*lai)
        photo_boost = 1.0 + g['c4_photosynthesis_boost']
        photo = light*self.leaf*g['photo_base_rate']*(0.5+0.5*self.nitrogen/10.0)*photo_boost

        resp = g['respiration_base'] + g['respiration_height_f']*self.height*(temp/20.0)
        if self.headed and not self.mature: resp *= 0.7
        transp = g['transpiration_per_leaf']*self.leaf*(temp/20.0)
        if self.headed and not self.mature: transp *= 0.6
        rd = self.root*self.plant_density/667.0
        uptake = g['water_uptake_eff']*self.root*aw*math.exp(-self.root_comp*rd)

        if self.energy > 1.0 and self.water > 0.5:
            self.nitrogen -= g['nitrogen_decay_rate']

        if self.energy > 1.0 and self.water > 0.5 and not self.headed:
            net_energy = photo - resp
            self.energy += net_energy
            self.water += uptake - transp
            aL, aR, aS = g['leaf_growth_alloc'], g['root_growth_alloc'], g['stem_growth_alloc']
            gc = g['growth_energy_cost']
            if self.stage in ["拔节期"] and self.height < self.max_height:
                self.height += aS*15*gc; self.energy -= gc*0.4; self.biomass += 0.03
            if self.root < self.max_root:
                self.root += aR*6*gc; self.energy -= gc*0.2; self.biomass += 0.01
            if self.leaf < self.leaf_max:
                self.leaf += aL*10*gc; self.energy -= gc*0.25; self.biomass += 0.02

        if self.headed and not self.mature:
            net_energy = photo - resp
            grain_gain = net_energy * g['grain_fill_allocation']
            self.grain_energy += grain_gain
            self.energy += net_energy - grain_gain
            self.water += uptake - transp
            self.leaf = max(0.1, self.leaf - g['leaf_senescence_rate'])
            fill_ratio = self.grain_energy/g['maturity_threshold']
            if fill_ratio > g['active_senescence_thresh']:
                mob = self.biomass*g['structural_reserve_fraction']*g['senescence_mobilization_rate']
                stem_sugar = self.height * g['stem_sugar_reserve']
                self.grain_energy += mob + stem_sugar
                self.biomass *= (1 - g['structural_reserve_fraction']*g['senescence_mobilization_rate'])
                self.leaf = max(0.1, self.leaf - g['leaf_senescence_rate']*2)

        self.water += uptake - transp
        self._update_stage()

        if self.alive:
            if self.water < g['irrigation_trigger'] and (self.age_hours - self.last_irrigation_hour) > 48:
                self.water += 20.0*0.7
                soil.moisture = min(soil.fc, soil.moisture+0.4)
                stressed = self.water < self.water_stress
                self.ops.append({'cost':50.0, 'stressed':stressed, 'type':'灌溉'})
                if stressed: self.energy -= 2.0
                self.last_irrigation_hour = self.age_hours

        if not self.headed and self.gdd >= self.gdd_heading and self.energy > g['repro_energy_thresh'] and self.age_days > g['repro_age_min']:
            self.headed = True; self.grain_energy = 3.0; self.energy -= g['repro_cost']

        if self.headed and not self.mature and self.grain_energy >= g['maturity_threshold']:
            self.mature = True; self.stage = "完熟"

        if self.energy <= 0: self.alive = False; self.death_cause = "能量耗尽"
        if self.water <= 0: self.alive = False; self.death_cause = "干旱致死"

    def _update_stage(self):
        if self.gdd < self.gdd_emergence: self.stage = "播种-出苗"
        elif self.gdd < self.gdd_jointing: self.stage = "苗期"
        elif self.gdd < self.gdd_heading: self.stage = "拔节期"
        elif self.headed and not self.mature: self.stage = "抽穗-灌浆"
        elif self.mature: self.stage = "完熟"
        else: self.stage = "成熟"

# ==================== 北大荒标准方案植格 ====================
class BeidahuangCornAgent:
    def __init__(self, genome):
        self.g = genome
        self.energy = 20.0; self.water = 12.0; self.nitrogen = 8.0
        self.height = 0.1; self.root = 0.1; self.leaf = 0.1
        self.biomass = 0.1; self.gdd = 0.0
        self.age_hours = 0; self.age_days = 0
        self.headed = False; self.mature = False
        self.grain_energy = 0.0
        self.alive = True; self.stage = "播种-出苗"; self.death_cause = None
        self.ops = []
        self.irrigation_done = {1: False, 2: False, 3: False}
        self.fertilizer_done = {1: False, 2: False}

        self.max_height = self.g['max_height']; self.max_root = self.g['max_root_depth']
        self.leaf_max = 6.0; self.water_stress = 2.0
        self.plant_density = self.g['plant_density']
        self.light_comp = self.g['light_comp']; self.root_comp = self.g['root_comp']
        self.gdd_emergence = self.g['gdd_emergence']
        self.gdd_jointing = self.g['gdd_jointing']
        self.gdd_heading = self.g['gdd_heading']
        self.gdd_maturity = self.g['gdd_maturity']

    def update(self, w, soil):
        if not self.alive or self.mature: return
        temp, precip, solar = w['temp'], w['precip'], w['solar']
        g = self.g

        self.age_hours += 1
        if self.age_hours % 24 == 0: self.age_days += 1
        self.gdd += max(0.0, (temp-10.0)/24.0)
        soil.update(precip, temp, self.root)
        aw = soil.aw()

        lai = self.leaf*self.plant_density/667.0
        light = solar*math.exp(-self.light_comp*lai)
        photo_boost = 1.0 + g['c4_photosynthesis_boost']
        photo = light*self.leaf*g['photo_base_rate']*(0.5+0.5*self.nitrogen/10.0)*photo_boost

        resp = g['respiration_base'] + g['respiration_height_f']*self.height*(temp/20.0)
        if self.headed and not self.mature: resp *= 0.7
        transp = g['transpiration_per_leaf']*self.leaf*(temp/20.0)
        if self.headed and not self.mature: transp *= 0.6
        rd = self.root*self.plant_density/667.0
        uptake = g['water_uptake_eff']*self.root*aw*math.exp(-self.root_comp*rd)

        if self.energy > 1.0 and self.water > 0.5:
            self.nitrogen -= g['nitrogen_decay_rate']

        if self.energy > 1.0 and self.water > 0.5 and not self.headed:
            net_energy = photo - resp
            self.energy += net_energy
            self.water += uptake - transp
            aL, aR, aS = g['leaf_growth_alloc'], g['root_growth_alloc'], g['stem_growth_alloc']
            gc = g['growth_energy_cost']
            if self.stage in ["拔节期"] and self.height < self.max_height:
                self.height += aS*15*gc; self.energy -= gc*0.4; self.biomass += 0.03
            if self.root < self.max_root:
                self.root += aR*6*gc; self.energy -= gc*0.2; self.biomass += 0.01
            if self.leaf < self.leaf_max:
                self.leaf += aL*10*gc; self.energy -= gc*0.25; self.biomass += 0.02

        if self.headed and not self.mature:
            net_energy = photo - resp
            grain_gain = net_energy * g['grain_fill_allocation']
            self.grain_energy += grain_gain
            self.energy += net_energy - grain_gain
            self.water += uptake - transp
            self.leaf = max(0.1, self.leaf - g['leaf_senescence_rate'])
            fill_ratio = self.grain_energy/g['maturity_threshold']
            if fill_ratio > g['active_senescence_thresh']:
                mob = self.biomass*g['structural_reserve_fraction']*g['senescence_mobilization_rate']
                stem_sugar = self.height * g['stem_sugar_reserve']
                self.grain_energy += mob + stem_sugar
                self.biomass *= (1 - g['structural_reserve_fraction']*g['senescence_mobilization_rate'])
                self.leaf = max(0.1, self.leaf - g['leaf_senescence_rate']*2)

        self.water += uptake - transp
        self._update_stage()

        # 北大荒标准灌溉：拔节期(日龄25-35)、大喇叭口期(日龄45-55)、灌浆期(日龄70-80)
        if not self.irrigation_done[1] and 25 <= self.age_days <= 35:
            self.water += 20.0*0.7; soil.moisture = min(soil.fc, soil.moisture+0.4)
            self.ops.append({'cost':50.0, 'type':'拔节灌溉'})
            self.irrigation_done[1] = True
        if not self.irrigation_done[2] and 45 <= self.age_days <= 55:
            self.water += 20.0*0.7; soil.moisture = min(soil.fc, soil.moisture+0.4)
            self.ops.append({'cost':50.0, 'type':'大喇叭口期灌溉'})
            self.irrigation_done[2] = True
        if not self.irrigation_done[3] and 70 <= self.age_days <= 80:
            self.water += 20.0*0.7; soil.moisture = min(soil.fc, soil.moisture+0.4)
            self.ops.append({'cost':50.0, 'type':'灌浆灌溉'})
            self.irrigation_done[3] = True

        # 北大荒标准追肥：基肥(0-5天)、大喇叭口期(45-55天)
        if not self.fertilizer_done[1] and 0 <= self.age_days <= 5:
            self.nitrogen = min(12.0, self.nitrogen + 3.0)
            self.ops.append({'cost':50.0, 'type':'基肥'})
            self.fertilizer_done[1] = True
        if not self.fertilizer_done[2] and 45 <= self.age_days <= 55:
            self.nitrogen = min(12.0, self.nitrogen + 2.5)
            self.ops.append({'cost':40.0, 'type':'大喇叭口期追肥'})
            self.fertilizer_done[2] = True

        if not self.headed and self.gdd >= self.gdd_heading and self.energy > g['repro_energy_thresh'] and self.age_days > g['repro_age_min']:
            self.headed = True; self.grain_energy = 3.0; self.energy -= g['repro_cost']

        if self.headed and not self.mature and self.grain_energy >= g['maturity_threshold']:
            self.mature = True; self.stage = "完熟"

        if self.energy <= 0: self.alive = False; self.death_cause = "能量耗尽"
        if self.water <= 0: self.alive = False; self.death_cause = "干旱致死"

    def _update_stage(self):
        if self.gdd < self.gdd_emergence: self.stage = "播种-出苗"
        elif self.gdd < self.gdd_jointing: self.stage = "苗期"
        elif self.gdd < self.gdd_heading: self.stage = "拔节期"
        elif self.headed and not self.mature: self.stage = "抽穗-灌浆"
        elif self.mature: self.stage = "完熟"
        else: self.stage = "成熟"

# ==================== 主程序 ====================
if __name__ == "__main__":
    cities = {
        "haerbin": "best_corn_genome_haerbin.json",
        "puyang": "best_corn_genome_puyang.json",
        "nanjing": "best_corn_genome_nanjing.json"
    }
    years = [2019, 2020, 2021, 2022]

    print("="*80)
    print("玉米回测：模型涌现策略 vs 北大荒标准农田方案")
    print("北大荒方案: 灌溉3次(拔节/大喇叭口/灌浆)+追肥2次(基肥/大喇叭口期)")
    print("="*80)

    for city, gene_file in cities.items():
        if not os.path.exists(gene_file):
            print(f"\n{city}: 基因文件不存在，跳过")
            continue
        with open(gene_file, 'r', encoding='utf-8') as f:
            genome = json.load(f)

        print(f"\n{'='*60}")
        print(f"  {city}")
        print(f"{'='*60}")
        print(f"{'年份':<10} {'模型-籽粒':>8} {'模型-灌溉':>6} {'模型-成本':>8} {'北大荒-籽粒':>10} {'北大荒-灌溉':>8} {'北大荒-成本':>10} {'籽粒差':>6} {'成本差':>8}")
        print("-"*80)

        total_model_cost = 0
        total_beidahuang_cost = 0
        total_model_grain = 0
        total_beidahuang_grain = 0

        for y in years:
            weather = build_season(".", city, y)

            agent_model = CornAgent(genome)
            soil = SimpleSoil()
            for w in weather:
                agent_model.update(w, soil)
                if not agent_model.alive or agent_model.mature:
                    break
            model_grain = agent_model.grain_energy
            model_cost = sum(op['cost'] for op in agent_model.ops)
            model_irrig = len([op for op in agent_model.ops if '灌溉' in op.get('type','')])

            agent_bdh = BeidahuangCornAgent(genome)
            soil = SimpleSoil()
            for w in weather:
                agent_bdh.update(w, soil)
                if not agent_bdh.alive or agent_bdh.mature:
                    break
            bdh_grain = agent_bdh.grain_energy
            bdh_cost = sum(op['cost'] for op in agent_bdh.ops)
            bdh_irrig = len([op for op in agent_bdh.ops if '灌溉' in op.get('type','')])

            total_model_cost += model_cost
            total_beidahuang_cost += bdh_cost
            total_model_grain += model_grain
            total_beidahuang_grain += bdh_grain

            print(f"{y}      {model_grain:8.1f} {model_irrig:6d} {model_cost:8.0f}   {bdh_grain:10.1f} {bdh_irrig:8d} {bdh_cost:10.0f}   {model_grain-bdh_grain:+6.1f} {model_cost-bdh_cost:+8.0f}")

        avg_model_grain = total_model_grain / len(years)
        avg_bdh_grain = total_beidahuang_grain / len(years)
        avg_model_cost = total_model_cost / len(years)
        avg_bdh_cost = total_beidahuang_cost / len(years)

        print("-"*80)
        print(f"{'四年平均':<10} {avg_model_grain:8.1f} {'':6} {avg_model_cost:8.0f}   {avg_bdh_grain:10.1f} {'':8} {avg_bdh_cost:10.0f}   {avg_model_grain-avg_bdh_grain:+6.1f} {avg_model_cost-avg_bdh_cost:+8.0f}")
        print(f"\n  → 模型比北大荒方案年均节省: {avg_bdh_cost-avg_model_cost:.0f} 元/亩")

    print("\n" + "="*80)
    print("回测完成")